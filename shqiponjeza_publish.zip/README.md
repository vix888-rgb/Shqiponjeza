# Shqiponjëza 🦅

Aplikacion mësimor për fëmijët e **klasës 1**: Matematikë, Gjuhë shqipe, Njeriu dhe natyra.
Mëso duke luajtur: nivele, yje, monedha, medalje dhe Foleja e Zogthit.

- Hape në telefon dhe zgjidh **"Shto në ekranin kryesor"** për ta instaluar.
- Punon edhe pa internet pas hapjes së parë.
- Pa reklama, pa chat, pa blerje. Progresi ruhet vetëm në pajisjen tënde.
